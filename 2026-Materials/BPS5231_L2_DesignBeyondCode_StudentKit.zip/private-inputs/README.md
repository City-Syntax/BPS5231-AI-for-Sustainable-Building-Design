# Private Inputs

Place your CV here locally, for example:

`private-inputs/CV.pdf`

This folder is listed in `.gitignore`, so it should not be committed to your public GitHub repository.

Attach your CV directly to Codex if needed so it can use the document as a content source.
